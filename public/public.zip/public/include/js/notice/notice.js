function showNoticeToast(msg) {
    $().toastmessage('showNoticeToast', msg);
}